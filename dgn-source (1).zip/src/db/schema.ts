import {
  boolean,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const genres = pgTable("genres", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
});

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  tagline: text("tagline").notNull(),
  synopsis: text("synopsis").notNull(),
  year: integer("year").notNull(),
  runtimeMinutes: integer("runtime_minutes").notNull(),
  contentRating: text("content_rating").notNull(),
  score: real("score").notNull(),
  posterUrl: text("poster_url").notNull(),
  backdropUrl: text("backdrop_url").notNull(),
  director: text("director").notNull(),
  country: text("country").notNull(),
  featured: boolean("featured").notNull().default(false),
  trending: boolean("trending").notNull().default(false),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

export const movieGenres = pgTable("movie_genres", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id")
    .notNull()
    .references(() => movies.id, { onDelete: "cascade" }),
  genreId: integer("genre_id")
    .notNull()
    .references(() => genres.id, { onDelete: "cascade" }),
});

export const castMembers = pgTable("cast_members", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id")
    .notNull()
    .references(() => movies.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  role: text("role").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  region: text("region").notNull(),
  status: text("status").notNull(),
  latencyMs: integer("latency_ms").notNull(),
  accent: text("accent").notNull(),
});

export const watchLinks = pgTable("watch_links", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id")
    .notNull()
    .references(() => movies.id, { onDelete: "cascade" }),
  serverId: integer("server_id")
    .notNull()
    .references(() => servers.id, { onDelete: "cascade" }),
  quality: text("quality").notNull(),
  language: text("language").notNull(),
  url: text("url").notNull(),
  fileSize: text("file_size").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const watchlist = pgTable(
  "watchlist",
  {
    id: serial("id").primaryKey(),
    visitorId: text("visitor_id").notNull(),
    movieId: integer("movie_id")
      .notNull()
      .references(() => movies.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("watchlist_visitor_movie").on(table.visitorId, table.movieId)],
);

export type Movie = typeof movies.$inferSelect;
export type Genre = typeof genres.$inferSelect;
export type Server = typeof servers.$inferSelect;
export type WatchLink = typeof watchLinks.$inferSelect;
export type CastMember = typeof castMembers.$inferSelect;
