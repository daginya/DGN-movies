import { db } from "@/db";
import {
  castMembers,
  genres,
  movieGenres,
  movies,
  servers,
  watchLinks,
} from "@/db/schema";
import { STREAMS } from "@/lib/videos";

type LinkSpec = {
  server: string;
  quality: string;
  language: string;
  url: string;
  fileSize: string;
};

type MovieSpec = {
  slug: string;
  title: string;
  tagline: string;
  synopsis: string;
  year: number;
  runtimeMinutes: number;
  contentRating: string;
  score: number;
  posterUrl: string;
  backdropUrl: string;
  director: string;
  country: string;
  featured?: boolean;
  trending?: boolean;
  genreSlugs: string[];
  cast: { name: string; role: string }[];
  links: LinkSpec[];
};

const GENRE_SEED = [
  { name: "Sci-Fi", slug: "sci-fi" },
  { name: "Thriller", slug: "thriller" },
  { name: "Drama", slug: "drama" },
  { name: "Mystery", slug: "mystery" },
  { name: "Fantasy", slug: "fantasy" },
  { name: "Adventure", slug: "adventure" },
  { name: "Crime", slug: "crime" },
  { name: "Noir", slug: "noir" },
  { name: "Action", slug: "action" },
  { name: "Romance", slug: "romance" },
  { name: "Horror", slug: "horror" },
  { name: "Animation", slug: "animation" },
  { name: "Family", slug: "family" },
  { name: "Western", slug: "western" },
  { name: "Documentary", slug: "documentary" },
  { name: "Comedy", slug: "comedy" },
];

const SERVER_SEED = [
  { name: "Nova Prime", code: "nova", region: "US-East", status: "online", latencyMs: 18, accent: "#e3b341" },
  { name: "Helix EU", code: "helix", region: "Frankfurt", status: "online", latencyMs: 42, accent: "#7dd3c0" },
  { name: "Atlas APAC", code: "atlas", region: "Singapore", status: "online", latencyMs: 68, accent: "#b9a0ff" },
  { name: "Pulse 4K", code: "pulse", region: "Global CDN", status: "online", latencyMs: 24, accent: "#ff8fab" },
  { name: "Archive Mirror", code: "archive", region: "Amsterdam", status: "degraded", latencyMs: 118, accent: "#c4b8a5" },
  { name: "Nightbird", code: "nightbird", region: "São Paulo", status: "online", latencyMs: 89, accent: "#ff9f5a" },
];

const MOVIE_SEED: MovieSpec[] = [
  {
    slug: "neon-harbor",
    title: "Neon Harbor",
    tagline: "The tide remembers every crime.",
    synopsis:
      "In a megaport drowned by rising seas, detective Jun Park hunts a stolen weather AI that only surfaces at high tide. Each server in the harbor’s black-market grid holds a different cut of the truth — and the wrong stream gets you erased with the next flood.",
    year: 2024,
    runtimeMinutes: 128,
    contentRating: "R",
    score: 8.4,
    posterUrl: "/images/posters/neon-harbor.jpg",
    backdropUrl: "/images/posters/neon-harbor.jpg",
    director: "Mina Cho",
    country: "South Korea",
    featured: true,
    trending: true,
    genreSlugs: ["sci-fi", "thriller"],
    cast: [
      { name: "Jun Park", role: "Detective Park" },
      { name: "Aisha Rahman", role: "Harbor AI" },
      { name: "Leo Voss", role: "Dock Boss" },
      { name: "Hana Kim", role: "Tide Keeper" },
    ],
    links: [
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.blazes, fileSize: "2.1 GB" },
      { server: "helix", quality: "720p", language: "English", url: STREAMS.escapes, fileSize: "1.2 GB" },
      { server: "pulse", quality: "4K", language: "English + KO", url: STREAMS.joyrides, fileSize: "6.4 GB" },
      { server: "atlas", quality: "1080p", language: "한국어", url: STREAMS.fun, fileSize: "2.0 GB" },
    ],
  },
  {
    slug: "the-last-lighthouse",
    title: "The Last Lighthouse",
    tagline: "The last analog signal on Earth.",
    synopsis:
      "When Mara inherits a crumbling Atlantic lighthouse, she discovers it is still broadcasting a forbidden analog frequency. Governments want the lamp dark. Sailors still steer by it. And the people who answer the signal should not exist.",
    year: 2023,
    runtimeMinutes: 116,
    contentRating: "PG-13",
    score: 8.1,
    posterUrl: "/images/posters/last-lighthouse.jpg",
    backdropUrl: "/images/posters/last-lighthouse.jpg",
    director: "Arthur Bell",
    country: "Ireland",
    featured: true,
    trending: false,
    genreSlugs: ["drama", "mystery"],
    cast: [
      { name: "Mara Quinn", role: "Keeper" },
      { name: "Owen Hale", role: "Coast Guard" },
      { name: "Siobhan Rea", role: "Mother" },
      { name: "Tomás Byrne", role: "Signal Thief" },
    ],
    links: [
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.subaru, fileSize: "1.9 GB" },
      { server: "helix", quality: "1080p", language: "English", url: STREAMS.gti, fileSize: "2.0 GB" },
      { server: "archive", quality: "480p", language: "English", url: STREAMS.whatcar, fileSize: "700 MB" },
    ],
  },
  {
    slug: "ember-court",
    title: "Ember Court",
    tagline: "Diplomacy, then fire.",
    synopsis:
      "A disgraced envoy is summoned to a volcanic empire where every treaty is tried in a court of living magma. To save her city she must win a case no outsider has survived — and choose which version of the verdict each server will carry home.",
    year: 2025,
    runtimeMinutes: 141,
    contentRating: "PG-13",
    score: 8.7,
    posterUrl: "/images/posters/ember-court.jpg",
    backdropUrl: "/images/posters/ember-court.jpg",
    director: "Sera Okonkwo",
    country: "Nigeria",
    featured: true,
    trending: true,
    genreSlugs: ["fantasy", "adventure"],
    cast: [
      { name: "Imani Adeyemi", role: "Envoy" },
      { name: "Kael Veyra", role: "Ash Prince" },
      { name: "Nura Sol", role: "Glass Advocate" },
      { name: "Rook Tan", role: "Ember Guard" },
    ],
    links: [
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.tears, fileSize: "8.1 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.meltdowns, fileSize: "2.4 GB" },
      { server: "nightbird", quality: "720p", language: "Español", url: STREAMS.bullrun, fileSize: "1.3 GB" },
      { server: "atlas", quality: "1080p", language: "English", url: STREAMS.joyrides, fileSize: "2.3 GB" },
    ],
  },
  {
    slug: "quiet-orbit",
    title: "Quiet Orbit",
    tagline: "Earth went silent. The work did not.",
    synopsis:
      "Two technicians keep a research station alive after Earth stops answering. Their only company is a stack of mirrored servers, each claiming a different last message from home. One of them is a lie that will kill the orbit.",
    year: 2024,
    runtimeMinutes: 109,
    contentRating: "PG-13",
    score: 8.0,
    posterUrl: "/images/posters/quiet-orbit.jpg",
    backdropUrl: "/images/posters/quiet-orbit.jpg",
    director: "Levin Hart",
    country: "Canada",
    featured: false,
    trending: true,
    genreSlugs: ["sci-fi", "drama"],
    cast: [
      { name: "Sam Ori", role: "Comms" },
      { name: "Rene Adler", role: "Systems" },
      { name: "Captain Ives", role: "Last Voice" },
      { name: "PIO-9", role: "Station AI" },
    ],
    links: [
      { server: "atlas", quality: "1080p", language: "English", url: STREAMS.tears, fileSize: "2.2 GB" },
      { server: "nova", quality: "720p", language: "English", url: STREAMS.escapes, fileSize: "1.1 GB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.sintel, fileSize: "5.8 GB" },
    ],
  },
  {
    slug: "velvet-heist",
    title: "Velvet Heist",
    tagline: "The painting remembers who stole it.",
    synopsis:
      "A jazz singer and a forger attempt the last elegant robbery in a city that has forgotten elegance. The canvas they lift is a living ledger — every previous thief still trapped in the varnish, arguing over which server should host the escape.",
    year: 2022,
    runtimeMinutes: 121,
    contentRating: "R",
    score: 7.9,
    posterUrl: "/images/posters/velvet-heist.jpg",
    backdropUrl: "/images/posters/velvet-heist.jpg",
    director: "Claudia Moreau",
    country: "France",
    featured: false,
    trending: true,
    genreSlugs: ["crime", "noir"],
    cast: [
      { name: "Lila Vane", role: "Singer" },
      { name: "Emile Roche", role: "Forger" },
      { name: "Inspector Brant", role: "Police" },
      { name: "Madame Kite", role: "Collector" },
    ],
    links: [
      { server: "helix", quality: "1080p", language: "Français", url: STREAMS.fun, fileSize: "2.0 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.gti, fileSize: "2.1 GB" },
      { server: "nightbird", quality: "720p", language: "Português", url: STREAMS.bullrun, fileSize: "1.2 GB" },
    ],
  },
  {
    slug: "sahara-protocol",
    title: "Sahara Protocol",
    tagline: "The border moves at noon.",
    synopsis:
      "Cartographer Nadia El-Sayed is hired to redraw a desert frontier that shifts every day. The protocol that governs it lives on six mirrored servers. If she publishes the wrong map, a city vanishes. If she publishes the right one, so does she.",
    year: 2025,
    runtimeMinutes: 124,
    contentRating: "PG-13",
    score: 7.6,
    posterUrl: "/images/posters/sahara-protocol.jpg",
    backdropUrl: "/images/posters/sahara-protocol.jpg",
    director: "Rami El-Sayed",
    country: "Morocco",
    featured: false,
    trending: false,
    genreSlugs: ["action", "thriller"],
    cast: [
      { name: "Nadia El-Sayed", role: "Cartographer" },
      { name: "Yusef Malik", role: "Guide" },
      { name: "Colonel Hart", role: "Protocol" },
      { name: "Leila Ben", role: "Fixer" },
    ],
    links: [
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.subaru, fileSize: "2.3 GB" },
      { server: "atlas", quality: "1080p", language: "العربية", url: STREAMS.meltdowns, fileSize: "2.2 GB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.joyrides, fileSize: "7.0 GB" },
      { server: "archive", quality: "480p", language: "English", url: STREAMS.whatcar, fileSize: "640 MB" },
    ],
  },
  {
    slug: "midnight-sonata",
    title: "Midnight Sonata",
    tagline: "The missing movement is a confession.",
    synopsis:
      "A pianist is hired to finish a concerto left incomplete for forty years. Each rehearsal hall streams a different take of the missing movement. Somewhere in the servers is the composer’s real last night — and the reason the music was never allowed to end.",
    year: 2023,
    runtimeMinutes: 102,
    contentRating: "PG-13",
    score: 8.2,
    posterUrl: "/images/posters/midnight-sonata.jpg",
    backdropUrl: "/images/posters/midnight-sonata.jpg",
    director: "Elena Voss",
    country: "Austria",
    featured: false,
    trending: false,
    genreSlugs: ["romance", "drama"],
    cast: [
      { name: "Clara Weiss", role: "Pianist" },
      { name: "Otto Kranz", role: "Patron" },
      { name: "Lina Kranz", role: "Daughter" },
      { name: "The Archivist", role: "Tape Keeper" },
    ],
    links: [
      { server: "helix", quality: "1080p", language: "Deutsch", url: STREAMS.escapes, fileSize: "1.8 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.fun, fileSize: "1.9 GB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.sintel, fileSize: "5.2 GB" },
    ],
  },
  {
    slug: "iron-orchard",
    title: "Iron Orchard",
    tagline: "The harvest came back wrong.",
    synopsis:
      "After a survey drone crashes in a family orchard, the trees begin growing fruit of rusted iron. Neighbors want it cut down. A corporation wants the seed. And the orchard’s private server starts broadcasting a harvest schedule for a crop that is not fruit.",
    year: 2024,
    runtimeMinutes: 98,
    contentRating: "R",
    score: 7.4,
    posterUrl: "/images/posters/iron-orchard.jpg",
    backdropUrl: "/images/posters/iron-orchard.jpg",
    director: "Jonah Pike",
    country: "United States",
    featured: false,
    trending: false,
    genreSlugs: ["thriller", "horror"],
    cast: [
      { name: "Ellen Marsh", role: "Grower" },
      { name: "Cal Marsh", role: "Son" },
      { name: "Dr. Pell", role: "Surveyor" },
      { name: "Sheriff Boone", role: "Sheriff" },
    ],
    links: [
      { server: "nightbird", quality: "1080p", language: "English", url: STREAMS.blazes, fileSize: "1.7 GB" },
      { server: "nova", quality: "720p", language: "English", url: STREAMS.meltdowns, fileSize: "980 MB" },
      { server: "archive", quality: "480p", language: "English", url: STREAMS.whatcar, fileSize: "510 MB" },
    ],
  },
  {
    slug: "glass-monsoon",
    title: "Glass Monsoon",
    tagline: "Once a year, the city rains knives.",
    synopsis:
      "Courier Rhee has twelve hours to cross a city that sheds its glass skin every monsoon. Roof routes, subway mirrors, and illegal stream relays all claim to be the safe path. She can trust only one server — and it will not tell her which.",
    year: 2021,
    runtimeMinutes: 118,
    contentRating: "PG-13",
    score: 7.8,
    posterUrl: "/images/posters/glass-monsoon.jpg",
    backdropUrl: "/images/posters/glass-monsoon.jpg",
    director: "Priya Nair",
    country: "India",
    featured: false,
    trending: true,
    genreSlugs: ["adventure", "sci-fi"],
    cast: [
      { name: "Rhee Das", role: "Courier" },
      { name: "Vikram Shah", role: "Dispatcher" },
      { name: "Anu Mehta", role: "Glass Saint" },
      { name: "Kiran", role: "Runner" },
    ],
    links: [
      { server: "atlas", quality: "1080p", language: "हिन्दी", url: STREAMS.bullrun, fileSize: "2.1 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.joyrides, fileSize: "2.2 GB" },
      { server: "helix", quality: "720p", language: "English", url: STREAMS.escapes, fileSize: "1.1 GB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.tears, fileSize: "6.9 GB" },
    ],
  },
  {
    slug: "paper-kingdom",
    title: "Paper Kingdom",
    tagline: "Fold once. The city folds back.",
    synopsis:
      "A child folds a paper city that begins collecting real citizens. Each crease is a street, each tear a border. When the original is uploaded to rival servers, three slightly different kingdoms go to war over a single missing crane.",
    year: 2022,
    runtimeMinutes: 94,
    contentRating: "PG",
    score: 8.5,
    posterUrl: "/images/posters/paper-kingdom.svg",
    backdropUrl: "/images/posters/paper-kingdom.svg",
    director: "Haruto Abe",
    country: "Japan",
    featured: false,
    trending: false,
    genreSlugs: ["animation", "family", "fantasy"],
    cast: [
      { name: "Yuki", role: "Folder" },
      { name: "The Crane", role: "Messenger" },
      { name: "Mayor Ink", role: "Paper Mayor" },
      { name: "Aunt Sora", role: "Aunt" },
    ],
    links: [
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.bunny, fileSize: "1.6 GB" },
      { server: "atlas", quality: "1080p", language: "日本語", url: STREAMS.elephants, fileSize: "1.7 GB" },
      { server: "helix", quality: "720p", language: "English", url: STREAMS.sintel, fileSize: "900 MB" },
    ],
  },
  {
    slug: "copper-sunday",
    title: "Copper Sunday",
    tagline: "One last parade before the mine is sealed.",
    synopsis:
      "A copper town throws its final Sunday parade as the mine is welded shut. The marching band, the sheriff, and the company man each upload a different cut of the day to the county servers. Only one version includes the body in the ore.",
    year: 2019,
    runtimeMinutes: 132,
    contentRating: "R",
    score: 7.7,
    posterUrl: "/images/posters/copper-sunday.svg",
    backdropUrl: "/images/posters/copper-sunday.svg",
    director: "Wade Ellison",
    country: "United States",
    featured: false,
    trending: false,
    genreSlugs: ["western", "drama"],
    cast: [
      { name: "Calder Boone", role: "Sheriff" },
      { name: "Ruth Vale", role: "Band Leader" },
      { name: "Henry Pike", role: "Company" },
      { name: "Kid Marrow", role: "Miner" },
    ],
    links: [
      { server: "nightbird", quality: "1080p", language: "English", url: STREAMS.subaru, fileSize: "2.5 GB" },
      { server: "nova", quality: "720p", language: "English", url: STREAMS.gti, fileSize: "1.3 GB" },
      { server: "archive", quality: "480p", language: "English", url: STREAMS.whatcar, fileSize: "720 MB" },
    ],
  },
  {
    slug: "the-atlas-room",
    title: "The Atlas Room",
    tagline: "Maps of countries that do not exist yet.",
    synopsis:
      "A map librarian finds a locked room of atlases for nations that have not been founded. Each night a new plate appears. Each plate is mirrored on a different server. Reading the wrong folio founds the country in the real world — with her as its first missing citizen.",
    year: 2020,
    runtimeMinutes: 111,
    contentRating: "PG-13",
    score: 8.3,
    posterUrl: "/images/posters/atlas-room.svg",
    backdropUrl: "/images/posters/atlas-room.svg",
    director: "Iris Lang",
    country: "United Kingdom",
    featured: true,
    trending: false,
    genreSlugs: ["mystery", "fantasy"],
    cast: [
      { name: "Edith Calder", role: "Librarian" },
      { name: "Mr. Quill", role: "Custodian" },
      { name: "Jonah Reed", role: "Cartographer" },
      { name: "The Index", role: "Voice" },
    ],
    links: [
      { server: "helix", quality: "1080p", language: "English", url: STREAMS.elephants, fileSize: "2.0 GB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.sintel, fileSize: "6.1 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.fun, fileSize: "1.9 GB" },
    ],
  },
  {
    slug: "northwire-signal",
    title: "Northwire Signal",
    tagline: "The last shortwave operators on Earth.",
    synopsis:
      "A documentary crew winters with the last analog radio operators above the Arctic Circle. Their towers still bounce voices between continents. When the satellite grid fails for eleven minutes, Northwire is the only server that hears who is still out there.",
    year: 2021,
    runtimeMinutes: 96,
    contentRating: "PG",
    score: 7.5,
    posterUrl: "/images/posters/northwire.svg",
    backdropUrl: "/images/posters/northwire.svg",
    director: "Sigrid Holm",
    country: "Norway",
    featured: false,
    trending: false,
    genreSlugs: ["documentary", "drama"],
    cast: [
      { name: "Lars Holm", role: "Operator" },
      { name: "Anya Petrova", role: "Operator" },
      { name: "Cam Reed", role: "Director" },
      { name: "Static", role: "The Grid" },
    ],
    links: [
      { server: "archive", quality: "1080p", language: "English", url: STREAMS.gti, fileSize: "1.8 GB" },
      { server: "helix", quality: "720p", language: "Norsk", url: STREAMS.subaru, fileSize: "1.0 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.whatcar, fileSize: "1.7 GB" },
    ],
  },
  {
    slug: "sintel",
    title: "Sintel",
    tagline: "A Blender Foundation open movie.",
    synopsis:
      "A young woman named Sintel searches for a baby dragon she raised, crossing a brutal landscape of ice, stone, and old magic. This is the Blender Institute’s open-source short — mirrored here across multiple public servers so you can compare streams, quality, and latency.",
    year: 2010,
    runtimeMinutes: 14,
    contentRating: "PG",
    score: 8.6,
    posterUrl: "/images/posters/sintel.svg",
    backdropUrl: "/images/posters/sintel.svg",
    director: "Colin Levy",
    country: "Netherlands",
    featured: false,
    trending: true,
    genreSlugs: ["animation", "fantasy", "adventure"],
    cast: [
      { name: "Halina Reijn", role: "Sintel" },
      { name: "Thom Hoffman", role: "Shaman" },
    ],
    links: [
      { server: "archive", quality: "1080p", language: "English", url: STREAMS.sintel, fileSize: "1.1 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.sintel, fileSize: "1.1 GB" },
      { server: "helix", quality: "720p", language: "English", url: STREAMS.sintel, fileSize: "620 MB" },
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.sintel, fileSize: "3.4 GB" },
    ],
  },
  {
    slug: "big-buck-bunny",
    title: "Big Buck Bunny",
    tagline: "A peaceful rabbit. Three terrible rodents.",
    synopsis:
      "The Peach Open Movie from the Blender Foundation. After a giant rabbit’s quiet morning is ruined by flying-squirrel bullies, he plans a very precise kind of revenge. Public-domain streaming, available on every DGN server.",
    year: 2008,
    runtimeMinutes: 10,
    contentRating: "G",
    score: 8.0,
    posterUrl: "/images/posters/bunny.svg",
    backdropUrl: "/images/posters/bunny.svg",
    director: "Sacha Goedegebure",
    country: "Netherlands",
    featured: false,
    trending: false,
    genreSlugs: ["animation", "comedy", "family"],
    cast: [
      { name: "Big Buck", role: "Bunny" },
      { name: "Frank", role: "Flying Squirrel" },
      { name: "Rinky", role: "Flying Squirrel" },
      { name: "Gimera", role: "Chinchilla" },
    ],
    links: [
      { server: "nova", quality: "1080p", language: "None", url: STREAMS.bunny, fileSize: "850 MB" },
      { server: "helix", quality: "1080p", language: "None", url: STREAMS.bunny, fileSize: "850 MB" },
      { server: "atlas", quality: "720p", language: "None", url: STREAMS.bunny, fileSize: "420 MB" },
      { server: "nightbird", quality: "1080p", language: "None", url: STREAMS.bunny, fileSize: "850 MB" },
    ],
  },
  {
    slug: "tears-of-steel",
    title: "Tears of Steel",
    tagline: "Amsterdam. Robots. A choice that ends the world.",
    synopsis:
      "The Blender Institute’s live-action/CGI short about a scientist, a robot army, and a love that has to be rewritten. Streamed from multiple public mirrors so you can test 4K Pulse against Archive’s analog-feel 480p.",
    year: 2012,
    runtimeMinutes: 12,
    contentRating: "PG-13",
    score: 7.8,
    posterUrl: "/images/posters/tears.svg",
    backdropUrl: "/images/posters/tears.svg",
    director: "Ian Hubert",
    country: "Netherlands",
    featured: false,
    trending: false,
    genreSlugs: ["sci-fi", "action", "animation"],
    cast: [
      { name: "Derek de Lint", role: "Celiu" },
      { name: "Sergio Hasselbaink", role: "Tux" },
      { name: "Vanja Rukavina", role: "Thom" },
    ],
    links: [
      { server: "pulse", quality: "4K", language: "English", url: STREAMS.tears, fileSize: "2.8 GB" },
      { server: "nova", quality: "1080p", language: "English", url: STREAMS.tears, fileSize: "980 MB" },
      { server: "archive", quality: "720p", language: "English", url: STREAMS.tears, fileSize: "540 MB" },
    ],
  },
  {
    slug: "elephants-dream",
    title: "Elephants Dream",
    tagline: "The first open movie.",
    synopsis:
      "Two characters wander a typewriter-ruled machine world in the original Blender Open Movie. Historic, strange, and still the best way to see how DGN’s servers disagree about a single reel.",
    year: 2006,
    runtimeMinutes: 11,
    contentRating: "PG",
    score: 7.2,
    posterUrl: "/images/posters/elephants.svg",
    backdropUrl: "/images/posters/elephants.svg",
    director: "Bassam Kurdali",
    country: "Netherlands",
    featured: false,
    trending: false,
    genreSlugs: ["animation", "fantasy"],
    cast: [
      { name: "Tygo Gernandt", role: "Proog" },
      { name: "Cas Jansen", role: "Emo" },
    ],
    links: [
      { server: "archive", quality: "1080p", language: "English", url: STREAMS.elephants, fileSize: "700 MB" },
      { server: "helix", quality: "720p", language: "English", url: STREAMS.elephants, fileSize: "380 MB" },
      { server: "atlas", quality: "1080p", language: "English", url: STREAMS.elephants, fileSize: "700 MB" },
    ],
  },
];

// Fill in any missing quality (4K → 360p) so every title offers the full range.
const QUALITY_PLAN: { quality: string; server: string; factor: number }[] = [
  { quality: "4K", server: "pulse", factor: 3.2 },
  { quality: "1440p", server: "helix", factor: 1.8 },
  { quality: "1080p", server: "nova", factor: 1 },
  { quality: "720p", server: "atlas", factor: 0.55 },
  { quality: "480p", server: "archive", factor: 0.3 },
  { quality: "360p", server: "nightbird", factor: 0.18 },
];

function parseSizeGb(size: string) {
  const n = parseFloat(size);
  if (Number.isNaN(n)) return 1.5;
  return /mb/i.test(size) ? n / 1024 : n;
}

function formatSize(gb: number) {
  return gb >= 1 ? `${gb.toFixed(1)} GB` : `${Math.max(80, Math.round(gb * 1024))} MB`;
}

function withAllQualities(links: LinkSpec[]): LinkSpec[] {
  if (links.length === 0) return links;
  const base = links.find((l) => l.quality === "1080p") ?? links[0];
  const plan = QUALITY_PLAN.find((p) => p.quality === base.quality);
  const baseGb = parseSizeGb(base.fileSize) / (plan?.factor ?? 1);
  const out = [...links];
  for (const step of QUALITY_PLAN) {
    if (out.some((l) => l.quality === step.quality)) continue;
    out.push({
      server: step.server,
      quality: step.quality,
      language: base.language,
      url: base.url,
      fileSize: formatSize(baseGb * step.factor),
    });
  }
  return out;
}

let seeding: Promise<void> | null = null;

export async function ensureSeeded() {
  if (!seeding) {
    seeding = (async () => {
      const existing = await db.select({ id: movies.id }).from(movies).limit(1);
      if (existing.length > 0) return;
      await seedDatabase();
    })().catch((error) => {
      seeding = null;
      throw error;
    });
  }
  await seeding;
}

export async function seedDatabase() {
  const insertedGenres = await db.insert(genres).values(GENRE_SEED).returning();
  const genreBySlug = new Map(insertedGenres.map((genre) => [genre.slug, genre.id]));

  const insertedServers = await db.insert(servers).values(SERVER_SEED).returning();
  const serverByCode = new Map(insertedServers.map((server) => [server.code, server.id]));

  for (const movie of MOVIE_SEED) {
    const [row] = await db
      .insert(movies)
      .values({
        slug: movie.slug,
        title: movie.title,
        tagline: movie.tagline,
        synopsis: movie.synopsis,
        year: movie.year,
        runtimeMinutes: movie.runtimeMinutes,
        contentRating: movie.contentRating,
        score: movie.score,
        posterUrl: movie.posterUrl,
        backdropUrl: movie.backdropUrl,
        director: movie.director,
        country: movie.country,
        featured: movie.featured ?? false,
        trending: movie.trending ?? false,
      })
      .returning();

    const genreIds = movie.genreSlugs
      .map((slug) => genreBySlug.get(slug))
      .filter((id): id is number => typeof id === "number");

    if (genreIds.length > 0) {
      await db.insert(movieGenres).values(genreIds.map((genreId) => ({ movieId: row.id, genreId })));
    }

    if (movie.cast.length > 0) {
      await db.insert(castMembers).values(
        movie.cast.map((member, index) => ({
          movieId: row.id,
          name: member.name,
          role: member.role,
          sortOrder: index,
        })),
      );
    }

    const links = withAllQualities(movie.links)
      .map((link) => {
        const serverId = serverByCode.get(link.server);
        if (!serverId) return null;
        return {
          movieId: row.id,
          serverId,
          quality: link.quality,
          language: link.language,
          url: link.url,
          fileSize: link.fileSize,
          isActive: true,
        };
      })
      .filter((link): link is NonNullable<typeof link> => link !== null);

    if (links.length > 0) {
      await db.insert(watchLinks).values(links);
    }
  }
}
