import Link from "next/link";
import { MovieCard } from "@/components/movie-card";
import { MovieRail } from "@/components/movie-rail";
import { StreamingServices } from "@/components/streaming-services";
import { formatRuntime, scoreLabel } from "@/lib/format";
import { catalogStats, listFeatured, listGenres, listMovies, listServers, listTrending } from "@/lib/queries";
import { site } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, trending, catalog, genres, servers, stats] = await Promise.all([
    listFeatured(),
    listTrending(),
    listMovies(),
    listGenres(),
    listServers(),
    catalogStats(),
  ]);

  const hero = featured[0] ?? catalog[0];
  const arrivals = catalog.slice(0, 10);

  return (
    <main>
      {hero ? (
        <section className="grain relative min-h-[86vh] overflow-hidden">
          <img
            src={hero.backdropUrl}
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-45"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/40" />
          <div className="relative mx-auto flex min-h-[86vh] max-w-7xl flex-col justify-end px-5 pb-16 pt-28 lg:px-8">
            <p className="text-[11px] uppercase tracking-[0.28em] text-accent">
              Now streaming on {hero.serverCount} servers
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-6xl leading-[0.95] text-paper sm:text-7xl">
              {hero.title}
            </h1>
            <p className="mt-5 max-w-xl text-lg text-body">{hero.tagline}</p>
            <p className="mt-4 flex flex-wrap gap-3 text-sm uppercase tracking-[0.16em] text-mute">
              <span>{hero.year}</span>
              <span>{hero.contentRating}</span>
              <span>{formatRuntime(hero.runtimeMinutes)}</span>
              <span>Score {scoreLabel(hero.score)}</span>
              {hero.genres.map((genre) => (
                <span key={genre.slug}>{genre.name}</span>
              ))}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href={`/movies/${hero.slug}`}
                className="rounded-full bg-accent px-6 py-3 text-sm font-medium text-onaccent hover:bg-accent-soft"
              >
                Watch now
              </Link>
              <Link
                href="/movies"
                className="rounded-full border border-accent/40 px-6 py-3 text-sm text-accent-soft hover:bg-accent/10"
              >
                Browse catalog
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <section className="-mt-6 overflow-hidden rounded-2xl border border-accent/15 bg-panel px-5 py-4">
          <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Live servers</p>
          <div className="mt-3 flex gap-6 overflow-x-auto text-sm text-body">
            {servers.map((server) => (
              <div key={server.id} className="flex shrink-0 items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ background: server.accent }} />
                <span>{server.name}</span>
                <span className="text-dim">{server.region}</span>
                <span className={server.status === "online" ? "text-emerald-600" : "text-amber-600"}>
                  {server.latencyMs}ms
                </span>
              </div>
            ))}
          </div>
        </section>

        <StreamingServices />

        <MovieRail kicker="This week" title="Trending across the grid" movies={trending} />

        <section className="mt-16 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div
            className="grain relative min-h-[320px] overflow-hidden rounded-3xl border border-accent/15"
            style={{ backgroundImage: "url(/images/hero.jpg)", backgroundSize: "cover", backgroundPosition: "center" }}
          >
            <div className="absolute inset-0 bg-ink/55" />
            <div className="relative flex h-full flex-col justify-end p-8">
              <p className="text-[11px] uppercase tracking-[0.22em] text-accent">{site.name} network</p>
              <h2 className="mt-2 font-display text-4xl">One catalog. Every server.</h2>
              <p className="mt-3 max-w-md text-body">
                {stats.movies} titles, {stats.links} mirrors, {stats.servers} independent streams. Pick a
                film, then pick the source that is fastest tonight.
              </p>
            </div>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Browse by mood</p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {genres.slice(0, 8).map((genre) => (
                <Link
                  key={genre.id}
                  href={`/movies?genre=${genre.slug}`}
                  className="rounded-2xl border border-accent/15 bg-panel px-4 py-5 transition hover:border-accent"
                >
                  <p className="font-display text-xl">{genre.name}</p>
                  <p className="mt-1 text-xs uppercase tracking-[0.16em] text-dim">Open shelf</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-16">
          <div className="mb-4 flex items-end justify-between">
            <h2 className="font-display text-3xl">The full house</h2>
            <Link href="/movies" className="text-sm text-accent hover:text-accent-soft">
              View all
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {arrivals.map((movie) => (
              <div key={movie.id} className="w-full">
                <MovieCard movie={movie} />
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
