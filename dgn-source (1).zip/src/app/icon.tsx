import { ImageResponse } from "next/og";
import { site } from "@/lib/site";

export const size = { width: 64, height: 64 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#7c3aed",
          border: "2px solid #ffffff",
          borderRadius: 12,
          color: "#ffffff",
          fontSize: 18,
          fontWeight: 700,
          letterSpacing: 2,
        }}
      >
        {site.name}
      </div>
    ),
    size,
  );
}
