import { MovieCard } from "@/components/movie-card";
import { listWatchlist } from "@/lib/queries";
import { getVisitorId } from "@/lib/visitor";

export const dynamic = "force-dynamic";

export default async function WatchlistPage() {
  const visitorId = await getVisitorId();
  const movies = await listWatchlist(visitorId);

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 lg:px-8">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Private reel</p>
      <h1 className="mt-2 font-display text-5xl">Watchlist</h1>
      <p className="mt-3 max-w-xl text-mute">
        Titles you pin stay on this browser. They are not shared, and they survive a refresh.
      </p>
      {movies.length === 0 ? (
        <p className="mt-12 text-mute">Nothing saved yet. Open a film and add it to the reel.</p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </main>
  );
}
