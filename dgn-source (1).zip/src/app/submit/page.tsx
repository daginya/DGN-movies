import { MovieForm } from "@/components/movie-form";
import { listGenres, listServers } from "@/lib/queries";
import { site } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function SubmitPage() {
  const [genres, servers] = await Promise.all([listGenres(), listServers()]);

  return (
    <main className="mx-auto max-w-3xl px-5 py-10 lg:px-8">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">{site.name} intake</p>
      <h1 className="mt-2 font-display text-5xl">Add a title</h1>
      <p className="mt-3 text-mute">
        Publish an original or public-domain film and attach the first streaming server. You can add
        more mirrors from the title page.
      </p>
      <div className="mt-8">
        <MovieForm genres={genres} servers={servers} />
      </div>
    </main>
  );
}
