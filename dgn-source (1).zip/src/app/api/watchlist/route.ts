import { NextRequest } from "next/server";
import { db } from "@/db";
import { movies, watchlist } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { listWatchlist } from "@/lib/queries";

export const dynamic = "force-dynamic";

function visitorIdFrom(request: NextRequest) {
  return request.cookies.get("dgn_vid")?.value ?? "anonymous";
}

export async function GET(request: NextRequest) {
  const moviesOnList = await listWatchlist(visitorIdFrom(request));
  return Response.json({ movies: moviesOnList });
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { movieId?: number };
    const movieId = Number(body.movieId);
    if (!movieId) return Response.json({ error: "movieId required" }, { status: 400 });

    const visitorId = visitorIdFrom(request);
    const [movie] = await db.select({ id: movies.id }).from(movies).where(eq(movies.id, movieId)).limit(1);
    if (!movie) return Response.json({ error: "Unknown title" }, { status: 404 });

    const [existing] = await db
      .select({ id: watchlist.id })
      .from(watchlist)
      .where(and(eq(watchlist.visitorId, visitorId), eq(watchlist.movieId, movieId)))
      .limit(1);

    if (existing) {
      await db.delete(watchlist).where(eq(watchlist.id, existing.id));
      return Response.json({ saved: false });
    }

    await db.insert(watchlist).values({ visitorId, movieId });
    return Response.json({ saved: true });
  } catch {
    return Response.json({ error: "Could not update watchlist." }, { status: 500 });
  }
}
