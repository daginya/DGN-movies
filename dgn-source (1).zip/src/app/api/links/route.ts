import { NextRequest } from "next/server";
import { QUALITIES } from "@/lib/qualities";
import { db } from "@/db";
import { movies, servers, watchLinks } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      movieId?: number;
      serverId?: number;
      quality?: string;
      language?: string;
      url?: string;
      fileSize?: string;
    };

    const movieId = Number(body.movieId);
    const serverId = Number(body.serverId);
    const url = body.url?.trim() ?? "";

    if (!movieId || !serverId || !url) {
      return Response.json({ error: "Movie, server, and URL are required." }, { status: 400 });
    }
    if (!/^https?:\/\//i.test(url) && !url.startsWith("/")) {
      return Response.json({ error: "Stream URL must be an http(s) link." }, { status: 400 });
    }

    const [movie] = await db.select({ id: movies.id }).from(movies).where(eq(movies.id, movieId)).limit(1);
    const [server] = await db.select({ id: servers.id }).from(servers).where(eq(servers.id, serverId)).limit(1);
    if (!movie || !server) {
      return Response.json({ error: "Unknown movie or server." }, { status: 404 });
    }

    const [link] = await db
      .insert(watchLinks)
      .values({
        movieId,
        serverId,
        quality: (QUALITIES as readonly string[]).includes(body.quality ?? "") ? body.quality! : "1080p",
        language: body.language?.trim() || "English",
        url,
        fileSize: body.fileSize?.trim() || "1.0 GB",
        isActive: true,
      })
      .returning();

    return Response.json({ id: link.id });
  } catch {
    return Response.json({ error: "Could not add server link." }, { status: 500 });
  }
}
