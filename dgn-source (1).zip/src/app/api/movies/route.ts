import { NextRequest } from "next/server";
import { QUALITIES } from "@/lib/qualities";
import { db } from "@/db";
import { movieGenres, movies, watchLinks } from "@/db/schema";
import { slugify } from "@/lib/format";
import { listMovies } from "@/lib/queries";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const data = await listMovies({
    q: searchParams.get("q") ?? undefined,
    genre: searchParams.get("genre") ?? undefined,
    year: searchParams.get("year") ?? undefined,
    server: searchParams.get("server") ?? undefined,
  });
  return Response.json({ movies: data });
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      title?: string;
      tagline?: string;
      synopsis?: string;
      year?: number;
      runtimeMinutes?: number;
      contentRating?: string;
      score?: number;
      director?: string;
      country?: string;
      posterUrl?: string;
      genreIds?: number[];
      featured?: boolean;
      trending?: boolean;
      link?: {
        serverId?: number;
        quality?: string;
        language?: string;
        url?: string;
        fileSize?: string;
      };
    };

    const title = body.title?.trim() ?? "";
    const tagline = body.tagline?.trim() ?? "";
    const synopsis = body.synopsis?.trim() ?? "";
    const director = body.director?.trim() ?? "";
    const country = body.country?.trim() ?? "";
    const year = Number(body.year);
    const runtimeMinutes = Number(body.runtimeMinutes);
    const score = Number(body.score);
    const url = body.link?.url?.trim() ?? "";
    const serverId = Number(body.link?.serverId);

    if (!title || !tagline || !synopsis || !director || !country) {
      return Response.json({ error: "Fill in the title, tagline, synopsis, director, and country." }, { status: 400 });
    }
    if (!year || !runtimeMinutes || Number.isNaN(score)) {
      return Response.json({ error: "Year, runtime, and score must be numbers." }, { status: 400 });
    }
    if (!url || !serverId) {
      return Response.json({ error: "A stream URL and server are required." }, { status: 400 });
    }
    if (!/^https?:\/\//i.test(url) && !url.startsWith("/")) {
      return Response.json({ error: "Stream URL must be an http(s) link." }, { status: 400 });
    }

    let slug = slugify(title) || `title-${Date.now()}`;
    const existing = await db.select({ id: movies.id }).from(movies).where(eq(movies.slug, slug)).limit(1);
    if (existing.length > 0) slug = `${slug}-${Date.now()}`;

    const posterUrl = body.posterUrl?.trim() || "/images/posters/fallback.svg";

    const [movie] = await db
      .insert(movies)
      .values({
        slug,
        title,
        tagline,
        synopsis,
        year,
        runtimeMinutes,
        contentRating: body.contentRating?.trim() || "PG-13",
        score,
        posterUrl,
        backdropUrl: posterUrl,
        director,
        country,
        featured: Boolean(body.featured),
        trending: Boolean(body.trending),
      })
      .returning();

    const genreIds = (body.genreIds ?? []).filter((id) => Number.isInteger(id) && id > 0);
    if (genreIds.length > 0) {
      await db.insert(movieGenres).values(genreIds.map((genreId) => ({ movieId: movie.id, genreId })));
    }

    await db.insert(watchLinks).values({
      movieId: movie.id,
      serverId,
      quality: (QUALITIES as readonly string[]).includes(body.link?.quality ?? "") ? body.link!.quality! : "1080p",
      language: body.link?.language?.trim() || "English",
      url,
      fileSize: body.link?.fileSize?.trim() || "1.0 GB",
      isActive: true,
    });

    return Response.json({ slug: movie.slug, id: movie.id });
  } catch {
    return Response.json({ error: "Could not publish title." }, { status: 500 });
  }
}
