import Link from "next/link";
import { site } from "@/lib/site";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-3xl px-5 py-24 text-center">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">404</p>
      <h1 className="mt-3 font-display text-5xl">This reel is missing</h1>
      <p className="mt-4 text-mute">The title may have been pulled from the {site.name} grid.</p>
      <Link href="/movies" className="mt-8 inline-block rounded-full bg-accent px-6 py-3 text-onaccent">
        Return to catalog
      </Link>
    </main>
  );
}
