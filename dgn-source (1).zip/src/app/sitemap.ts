import type { MetadataRoute } from "next";
import { listMovies } from "@/lib/queries";
import { site } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = site.url;
  const movies = await listMovies();

  return [
    { url: base, changeFrequency: "daily", priority: 1 },
    { url: `${base}/movies`, changeFrequency: "daily", priority: 0.9 },
    { url: `${base}/servers`, changeFrequency: "weekly", priority: 0.6 },
    { url: `${base}/submit`, changeFrequency: "monthly", priority: 0.4 },
    ...movies.map((movie) => ({
      url: `${base}/movies/${movie.slug}`,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
  ];
}
