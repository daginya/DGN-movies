import Link from "next/link";
import { serverStats } from "@/lib/queries";
import { site } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function ServersPage() {
  const servers = await serverStats();

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 lg:px-8">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Infrastructure</p>
      <h1 className="mt-2 font-display text-5xl">Streaming servers</h1>
      <p className="mt-3 max-w-2xl text-mute">
        Every title on {site.name} can be mirrored. Choose the node with the lowest latency, or keep
        a slower archive copy as backup.
      </p>
      <div className="mt-10 grid gap-4 md:grid-cols-2">
        {servers.map((server) => (
          <Link
            key={server.serverId}
            href={`/movies?server=${server.code}`}
            className="rounded-3xl border border-accent/15 bg-panel p-6 transition hover:border-accent"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="h-3 w-3 rounded-full" style={{ background: server.accent }} />
                <h2 className="font-display text-3xl">{server.name}</h2>
              </div>
              <span className={server.status === "online" ? "text-emerald-600" : "text-amber-600"}>
                {server.status}
              </span>
            </div>
            <p className="mt-4 text-sm uppercase tracking-[0.16em] text-dim">
              {server.region} · {server.latencyMs}ms · {server.links} links
            </p>
          </Link>
        ))}
      </div>
    </main>
  );
}
