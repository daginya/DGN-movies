import Link from "next/link";
import { notFound } from "next/navigation";
import { LinkForm } from "@/components/link-form";
import { MovieCard } from "@/components/movie-card";
import { Player } from "@/components/player";
import { WatchlistButton } from "@/components/watchlist-button";
import { formatRuntime, scoreLabel } from "@/lib/format";
import { getMovieBySlug, isOnWatchlist, listServers, listSimilar } from "@/lib/queries";
import { getVisitorId } from "@/lib/visitor";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const movie = await getMovieBySlug(slug);
  if (!movie) return { title: "Title not found" };
  return { title: movie.title, description: movie.tagline };
}

export default async function MoviePage({ params }: { params: Params }) {
  const { slug } = await params;
  const movie = await getMovieBySlug(slug);
  if (!movie) notFound();

  const visitorId = await getVisitorId();
  const [saved, similar, servers] = await Promise.all([
    isOnWatchlist(visitorId, movie.id),
    listSimilar(
      movie.id,
      movie.genres.map((genre) => genre.slug),
    ),
    listServers(),
  ]);

  return (
    <main>
      <section className="grain relative min-h-[42vh] overflow-hidden">
        <img src={movie.backdropUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/70 to-ink/40" />
        <div className="relative mx-auto grid max-w-7xl gap-8 px-5 pb-10 pt-16 lg:grid-cols-[200px_1fr] lg:px-8">
          <img
            src={movie.posterUrl}
            alt={`${movie.title} poster`}
            className="hidden w-[200px] rounded-xl poster-shadow lg:block"
          />
          <div className="flex flex-col justify-end">
            <p className="text-[11px] uppercase tracking-[0.22em] text-accent">
              {movie.country} · {movie.director}
            </p>
            <h1 className="mt-2 font-display text-5xl sm:text-6xl">{movie.title}</h1>
            <p className="mt-3 max-w-2xl text-lg text-body">{movie.tagline}</p>
            <p className="mt-4 flex flex-wrap gap-3 text-sm uppercase tracking-[0.14em] text-mute">
              <span>{movie.year}</span>
              <span>{movie.contentRating}</span>
              <span>{formatRuntime(movie.runtimeMinutes)}</span>
              <span>{scoreLabel(movie.score)}</span>
              {movie.genres.map((genre) => (
                <Link key={genre.slug} href={`/movies?genre=${genre.slug}`} className="hover:text-accent-soft">
                  {genre.name}
                </Link>
              ))}
            </p>
            <div className="mt-6">
              <WatchlistButton movieId={movie.id} saved={saved} />
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-8 lg:grid-cols-[minmax(0,1fr)_300px] lg:px-8">
        <div>
          <Player title={movie.title} posterUrl={movie.posterUrl} links={movie.links} />
          <p className="mt-8 max-w-3xl text-base leading-7 text-body">{movie.synopsis}</p>
          {movie.cast.length > 0 ? (
            <div className="mt-8">
              <h2 className="font-display text-2xl">Cast</h2>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {movie.cast.map((member) => (
                  <li key={`${member.name}-${member.role}`} className="rounded-xl border border-accent/15 px-4 py-3">
                    <p className="text-paper">{member.name}</p>
                    <p className="text-sm text-dim">{member.role}</p>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
        <aside className="space-y-6">
          <div className="rounded-2xl border border-accent/15 bg-panel p-5">
            <p className="text-[11px] uppercase tracking-[0.2em] text-accent">Mirrors</p>
            <ul className="mt-3 space-y-3 text-sm">
              {movie.links.map((link) => (
                <li key={link.id} className="flex items-start justify-between gap-3">
                  <span>
                    <span className="block text-paper">{link.server.name}</span>
                    <span className="text-xs text-dim">
                      {link.quality} · {link.language} · {link.fileSize}
                    </span>
                  </span>
                  <span className={link.server.status === "online" ? "text-emerald-600" : "text-amber-600"}>
                    {link.server.latencyMs}ms
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <LinkForm movieId={movie.id} servers={servers} />
        </aside>
      </div>

      {similar.length > 0 ? (
        <section className="mx-auto max-w-7xl px-5 pb-16 lg:px-8">
          <h2 className="font-display text-3xl">Because you opened this</h2>
          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {similar.map((item) => (
              <MovieCard key={item.id} movie={item} />
            ))}
          </div>
        </section>
      ) : null}
    </main>
  );
}
