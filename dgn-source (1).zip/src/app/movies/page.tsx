import Link from "next/link";
import { MovieCard } from "@/components/movie-card";
import { QUALITIES } from "@/lib/qualities";
import { StreamingServices } from "@/components/streaming-services";
import { listGenres, listMovies, listServers } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Search = Promise<{ q?: string; genre?: string; year?: string; server?: string; quality?: string }>;

export default async function MoviesPage({ searchParams }: { searchParams: Search }) {
  const params = await searchParams;
  const [movies, genres, servers] = await Promise.all([
    listMovies({
      q: params.q,
      genre: params.genre,
      year: params.year,
      server: params.server,
      quality: params.quality,
    }),
    listGenres(),
    listServers(),
  ]);

  const years = ["2025", "2024", "2023", "2022", "2021", "2020", "2019", "2012", "2010", "2008", "2006"];

  function href(next: Record<string, string | undefined>) {
    const merged = { ...params, ...next };
    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(merged)) {
      if (value) query.set(key, value);
    }
    const text = query.toString();
    return text ? `/movies?${text}` : "/movies";
  }

  return (
    <main className="mx-auto max-w-7xl px-5 py-10 lg:px-8">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Catalog</p>
      <h1 className="mt-2 font-display text-5xl">Every title, every mirror</h1>
      <p className="mt-3 max-w-2xl text-mute">
        Filter by genre, year, or the server you want to watch from. Open a film to switch sources live.
      </p>

      <div className="mt-8 flex flex-wrap gap-2">
        <Link
          href={href({ genre: undefined })}
          className={`rounded-full border px-3 py-1 text-xs uppercase tracking-[0.14em] ${
            !params.genre ? "border-accent text-accent-soft" : "border-accent/20 text-mute"
          }`}
        >
          All genres
        </Link>
        {genres.map((genre) => (
          <Link
            key={genre.id}
            href={href({ genre: genre.slug })}
            className={`rounded-full border px-3 py-1 text-xs uppercase tracking-[0.14em] ${
              params.genre === genre.slug
                ? "border-accent text-accent-soft"
                : "border-accent/20 text-mute"
            }`}
          >
            {genre.name}
          </Link>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {years.map((year) => (
          <Link
            key={year}
            href={href({ year: params.year === year ? undefined : year })}
            className={`rounded-full border px-3 py-1 text-xs ${
              params.year === year ? "border-accent text-accent-soft" : "border-accent/20 text-mute"
            }`}
          >
            {year}
          </Link>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {servers.map((server) => (
          <Link
            key={server.id}
            href={href({ server: params.server === server.code ? undefined : server.code })}
            className={`rounded-full border px-3 py-1 text-xs ${
              params.server === server.code
                ? "border-accent text-accent-soft"
                : "border-accent/20 text-mute"
            }`}
          >
            {server.name}
          </Link>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="mr-1 text-[11px] uppercase tracking-[0.18em] text-dim">Quality</span>
        {QUALITIES.map((q) => (
          <Link
            key={q}
            href={href({ quality: params.quality === q ? undefined : q })}
            className={`rounded-lg border px-3 py-1 text-xs font-medium ${
              params.quality === q ? "border-accent bg-accent text-onaccent" : "border-accent/20 text-mute"
            }`}
          >
            {q}
          </Link>
        ))}
      </div>

      <p className="mt-8 text-sm text-dim">
        {movies.length} title{movies.length === 1 ? "" : "s"}
        {params.q ? ` for “${params.q}”` : ""}
      </p>

      {movies.length === 0 ? (
        <p className="mt-10 text-mute">No titles match those filters. Try another shelf.</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}

      <StreamingServices title="More places to watch" />
    </main>
  );
}
