// Official streaming services shown in the "Where to watch" section.
// Add, remove, or reorder entries here.
export type StreamingService = {
  name: string;
  url: string;
  color: string; // brand-ish tile color
  note: string;
};

export const streamingServices: StreamingService[] = [
  { name: "Netflix", url: "https://www.netflix.com", color: "#e50914", note: "Subscription" },
  { name: "Prime Video", url: "https://www.primevideo.com", color: "#00a8e1", note: "Subscription · Rent · Buy" },
  { name: "Apple TV+", url: "https://tv.apple.com", color: "#000000", note: "Subscription · Rent · Buy" },
  { name: "Disney+", url: "https://www.disneyplus.com", color: "#113ccf", note: "Subscription" },
  { name: "HBO Max", url: "https://www.hbomax.com", color: "#5822b4", note: "Subscription" },
  { name: "Hulu", url: "https://www.hulu.com", color: "#1ce783", note: "Subscription" },
  { name: "Paramount+", url: "https://www.paramountplus.com", color: "#0064ff", note: "Subscription" },
  { name: "Peacock", url: "https://www.peacocktv.com", color: "#111111", note: "Free · Subscription" },
  { name: "YouTube Movies", url: "https://www.youtube.com/movies", color: "#ff0000", note: "Free · Rent · Buy" },
  { name: "Google TV", url: "https://tv.google", color: "#4285f4", note: "Rent · Buy" },
  { name: "Crunchyroll", url: "https://www.crunchyroll.com", color: "#f47521", note: "Anime · Free · Subscription" },
  { name: "Showmax", url: "https://www.showmax.com", color: "#e4003a", note: "Subscription" },
  { name: "Starz", url: "https://www.starz.com", color: "#0a0a0a", note: "Subscription" },
  { name: "MUBI", url: "https://mubi.com", color: "#001489", note: "Arthouse · Subscription" },
  { name: "Criterion Channel", url: "https://www.criterionchannel.com", color: "#1a1a1a", note: "Classics · Subscription" },
  { name: "Tubi", url: "https://tubitv.com", color: "#7408ff", note: "Free with ads" },
  { name: "Pluto TV", url: "https://pluto.tv", color: "#2c2c2c", note: "Free with ads" },
  { name: "Plex", url: "https://www.plex.tv", color: "#e5a00d", note: "Free with ads" },
  { name: "Kanopy", url: "https://www.kanopy.com", color: "#e4572e", note: "Free with library card" },
];
