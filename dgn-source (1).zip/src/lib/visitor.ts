import { cookies } from "next/headers";

export async function getVisitorId() {
  const jar = await cookies();
  return jar.get("dgn_vid")?.value ?? "anonymous";
}
