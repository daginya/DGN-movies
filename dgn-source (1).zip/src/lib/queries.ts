import { db } from "@/db";
import {
  castMembers,
  genres,
  movieGenres,
  movies,
  servers,
  watchLinks,
  watchlist,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { qualityRank, sortQualities } from "@/lib/qualities";
import { and, asc, desc, eq, ilike, inArray, or, sql, type SQL } from "drizzle-orm";

export type MovieCardData = {
  id: number;
  slug: string;
  title: string;
  tagline: string;
  year: number;
  runtimeMinutes: number;
  contentRating: string;
  score: number;
  posterUrl: string;
  backdropUrl: string;
  director: string;
  featured: boolean;
  trending: boolean;
  genres: { name: string; slug: string }[];
  serverCount: number;
  qualities: string[];
};

export type WatchLinkData = {
  id: number;
  quality: string;
  language: string;
  url: string;
  fileSize: string;
  isActive: boolean;
  server: {
    id: number;
    name: string;
    code: string;
    region: string;
    status: string;
    latencyMs: number;
    accent: string;
  };
};

export type MovieDetail = MovieCardData & {
  synopsis: string;
  country: string;
  cast: { name: string; role: string }[];
  links: WatchLinkData[];
};

async function attachGenresAndCounts<T extends { id: number }>(
  rows: T[],
): Promise<(T & { genres: { name: string; slug: string }[]; serverCount: number; qualities: string[] })[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((row) => row.id);

  const genreRows = await db
    .select({
      movieId: movieGenres.movieId,
      name: genres.name,
      slug: genres.slug,
    })
    .from(movieGenres)
    .innerJoin(genres, eq(movieGenres.genreId, genres.id))
    .where(inArray(movieGenres.movieId, ids));

  const countRows = await db
    .select({
      movieId: watchLinks.movieId,
      count: sql<number>`count(*)::int`,
    })
    .from(watchLinks)
    .where(and(inArray(watchLinks.movieId, ids), eq(watchLinks.isActive, true)))
    .groupBy(watchLinks.movieId);

  const qualityRows = await db
    .selectDistinct({ movieId: watchLinks.movieId, quality: watchLinks.quality })
    .from(watchLinks)
    .where(and(inArray(watchLinks.movieId, ids), eq(watchLinks.isActive, true)));

  const qualitiesByMovie = new Map<number, string[]>();
  for (const row of qualityRows) {
    const list = qualitiesByMovie.get(row.movieId) ?? [];
    list.push(row.quality);
    qualitiesByMovie.set(row.movieId, list);
  }

  const genresByMovie = new Map<number, { name: string; slug: string }[]>();
  for (const row of genreRows) {
    const list = genresByMovie.get(row.movieId) ?? [];
    list.push({ name: row.name, slug: row.slug });
    genresByMovie.set(row.movieId, list);
  }

  const countByMovie = new Map(countRows.map((row) => [row.movieId, row.count]));

  return rows.map((row) => ({
    ...row,
    genres: genresByMovie.get(row.id) ?? [],
    serverCount: countByMovie.get(row.id) ?? 0,
    qualities: sortQualities(qualitiesByMovie.get(row.id) ?? []),
  }));
}

export async function listGenres() {
  await ensureSeeded();
  return db.select().from(genres).orderBy(asc(genres.name));
}

export async function listServers() {
  await ensureSeeded();
  return db.select().from(servers).orderBy(asc(servers.latencyMs));
}

export async function listMovies(filters: {
  q?: string;
  genre?: string;
  year?: string;
  server?: string;
  quality?: string;
} = {}): Promise<MovieCardData[]> {
  await ensureSeeded();

  const conditions: SQL[] = [];
  if (filters.q) {
    const needle = `%${filters.q}%`;
    const search = or(
      ilike(movies.title, needle),
      ilike(movies.tagline, needle),
      ilike(movies.director, needle),
      ilike(movies.synopsis, needle),
    );
    if (search) conditions.push(search);
  }
  if (filters.year) {
    const year = Number(filters.year);
    if (!Number.isNaN(year)) conditions.push(eq(movies.year, year));
  }

  let movieIds: number[] | null = null;

  if (filters.genre) {
    const genreMatch = await db
      .select({ movieId: movieGenres.movieId })
      .from(movieGenres)
      .innerJoin(genres, eq(movieGenres.genreId, genres.id))
      .where(eq(genres.slug, filters.genre));
    movieIds = genreMatch.map((row) => row.movieId);
  }

  if (filters.server) {
    const serverMatch = await db
      .select({ movieId: watchLinks.movieId })
      .from(watchLinks)
      .innerJoin(servers, eq(watchLinks.serverId, servers.id))
      .where(eq(servers.code, filters.server));
    const serverIds = serverMatch.map((row) => row.movieId);
    movieIds = movieIds ? movieIds.filter((id) => serverIds.includes(id)) : serverIds;
  }

  if (filters.quality) {
    const qualityMatch = await db
      .selectDistinct({ movieId: watchLinks.movieId })
      .from(watchLinks)
      .where(and(eq(watchLinks.quality, filters.quality), eq(watchLinks.isActive, true)));
    const qualityIds = qualityMatch.map((row) => row.movieId);
    movieIds = movieIds ? movieIds.filter((id) => qualityIds.includes(id)) : qualityIds;
  }

  if (movieIds) {
    if (movieIds.length === 0) return [];
    conditions.push(inArray(movies.id, movieIds));
  }

  const rows = await db
    .select()
    .from(movies)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(movies.featured), desc(movies.trending), desc(movies.score), desc(movies.year));

  return attachGenresAndCounts(rows);
}

export async function listFeatured(): Promise<MovieCardData[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(movies)
    .where(eq(movies.featured, true))
    .orderBy(desc(movies.score));
  return attachGenresAndCounts(rows);
}

export async function listTrending(): Promise<MovieCardData[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(movies)
    .where(eq(movies.trending, true))
    .orderBy(desc(movies.score));
  return attachGenresAndCounts(rows);
}

export async function getMovieBySlug(slug: string): Promise<MovieDetail | null> {
  await ensureSeeded();
  const [movie] = await db.select().from(movies).where(eq(movies.slug, slug)).limit(1);
  if (!movie) return null;

  const [withMeta] = await attachGenresAndCounts([movie]);

  const cast = await db
    .select()
    .from(castMembers)
    .where(eq(castMembers.movieId, movie.id))
    .orderBy(asc(castMembers.sortOrder));

  const links = await db
    .select({
      id: watchLinks.id,
      quality: watchLinks.quality,
      language: watchLinks.language,
      url: watchLinks.url,
      fileSize: watchLinks.fileSize,
      isActive: watchLinks.isActive,
      serverId: servers.id,
      serverName: servers.name,
      serverCode: servers.code,
      region: servers.region,
      status: servers.status,
      latencyMs: servers.latencyMs,
      accent: servers.accent,
    })
    .from(watchLinks)
    .innerJoin(servers, eq(watchLinks.serverId, servers.id))
    .where(eq(watchLinks.movieId, movie.id))
    .orderBy(asc(servers.latencyMs));
  links.sort((a, b) => qualityRank(a.quality) - qualityRank(b.quality) || a.latencyMs - b.latencyMs);

  return {
    ...withMeta,
    synopsis: movie.synopsis,
    country: movie.country,
    cast: cast.map((member) => ({ name: member.name, role: member.role })),
    links: links.map((link) => ({
      id: link.id,
      quality: link.quality,
      language: link.language,
      url: link.url,
      fileSize: link.fileSize,
      isActive: link.isActive,
      server: {
        id: link.serverId,
        name: link.serverName,
        code: link.serverCode,
        region: link.region,
        status: link.status,
        latencyMs: link.latencyMs,
        accent: link.accent,
      },
    })),
  };
}

export async function listSimilar(movieId: number, genreSlugs: string[]): Promise<MovieCardData[]> {
  await ensureSeeded();
  if (genreSlugs.length === 0) {
    const rows = await db
      .select()
      .from(movies)
      .where(sql`${movies.id} <> ${movieId}`)
      .orderBy(desc(movies.score))
      .limit(6);
    return attachGenresAndCounts(rows);
  }

  const matches = await db
    .select({ movieId: movieGenres.movieId })
    .from(movieGenres)
    .innerJoin(genres, eq(movieGenres.genreId, genres.id))
    .where(and(inArray(genres.slug, genreSlugs), sql`${movieGenres.movieId} <> ${movieId}`));

  const ids = [...new Set(matches.map((row) => row.movieId))].slice(0, 8);
  if (ids.length === 0) return [];

  const rows = await db.select().from(movies).where(inArray(movies.id, ids)).orderBy(desc(movies.score));
  return attachGenresAndCounts(rows);
}

export async function listWatchlist(visitorId: string): Promise<MovieCardData[]> {
  await ensureSeeded();
  const rows = await db
    .select({ movie: movies })
    .from(watchlist)
    .innerJoin(movies, eq(watchlist.movieId, movies.id))
    .where(eq(watchlist.visitorId, visitorId))
    .orderBy(desc(watchlist.createdAt));
  return attachGenresAndCounts(rows.map((row) => row.movie));
}

export async function isOnWatchlist(visitorId: string, movieId: number) {
  const [row] = await db
    .select({ id: watchlist.id })
    .from(watchlist)
    .where(and(eq(watchlist.visitorId, visitorId), eq(watchlist.movieId, movieId)))
    .limit(1);
  return Boolean(row);
}

export async function serverStats() {
  await ensureSeeded();
  const rows = await db
    .select({
      serverId: servers.id,
      name: servers.name,
      code: servers.code,
      region: servers.region,
      status: servers.status,
      latencyMs: servers.latencyMs,
      accent: servers.accent,
      links: sql<number>`count(${watchLinks.id})::int`,
    })
    .from(servers)
    .leftJoin(watchLinks, eq(watchLinks.serverId, servers.id))
    .groupBy(servers.id)
    .orderBy(asc(servers.latencyMs));
  return rows;
}

export async function catalogStats() {
  await ensureSeeded();
  const [movieCount] = await db.select({ count: sql<number>`count(*)::int` }).from(movies);
  const [linkCount] = await db.select({ count: sql<number>`count(*)::int` }).from(watchLinks);
  const [serverCount] = await db.select({ count: sql<number>`count(*)::int` }).from(servers);
  return {
    movies: movieCount?.count ?? 0,
    links: linkCount?.count ?? 0,
    servers: serverCount?.count ?? 0,
  };
}
