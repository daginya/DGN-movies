// Supported stream qualities, best first.
export const QUALITIES = ["4K", "1440p", "1080p", "720p", "480p", "360p"] as const;
export type Quality = (typeof QUALITIES)[number];

export const QUALITY_LABEL: Record<string, string> = {
  "4K": "4K · 2160p",
  "1440p": "2K · 1440p",
  "1080p": "Full HD · 1080p",
  "720p": "HD · 720p",
  "480p": "SD · 480p",
  "360p": "Low · 360p",
};

export function qualityRank(q: string) {
  const i = (QUALITIES as readonly string[]).indexOf(q);
  return i === -1 ? QUALITIES.length : i;
}

export function sortQualities(list: string[]) {
  return [...new Set(list)].sort((a, b) => qualityRank(a) - qualityRank(b));
}
