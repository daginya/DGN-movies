/**
 * ─────────────────────────────────────────────────────────────
 *  SITE CONFIG — this is the file that makes the site YOURS.
 *  Change the values here and the whole app rebrands.
 *  Colors live in src/app/globals.css under the @theme block.
 * ─────────────────────────────────────────────────────────────
 */
export const site = {
  /** Short brand name shown in the header badge, footer, and tab title. */
  name: "DGN",
  /** Small line under the wordmark in the header. */
  label: "Movies",
  /** One-line description used in metadata and the footer. */
  tagline: "Movies from every server",
  description:
    "DGN is a cinematic catalog of original titles and open movies, each with watch links mirrored across independent streaming servers.",
  /** The domain people will visit. Used for canonical URLs and metadata. */
  domain: "dgnmovies.com",
  /** Optional override — set NEXT_PUBLIC_SITE_URL in .env when you deploy. */
  get url() {
    return process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ?? `https://${this.domain}`;
  },
  /** Footer blurb. */
  footerNote:
    "A catalog of original titles and open movies, each mirrored across independent streaming servers. Switch sources, compare quality, keep a watchlist.",
  /** Primary navigation. */
  nav: [
    { href: "/movies", label: "Catalog" },
    { href: "/servers", label: "Servers" },
    { href: "/watchlist", label: "Watchlist" },
    { href: "/submit", label: "Add title" },
  ],
  /** Footer links. */
  footerLinks: [
    { href: "/movies", label: "Catalog" },
    { href: "/servers", label: "Servers" },
    { href: "/submit", label: "Submit" },
  ],
  /** Contact / social slots shown in the footer. Leave a string empty to hide it. */
  contact: {
    email: "hello@dgnmovies.com",
    x: "",
    instagram: "",
    telegram: "",
  },
} as const;
