import { MovieCard } from "@/components/movie-card";
import type { MovieCardData } from "@/lib/queries";

export function MovieRail({
  title,
  kicker,
  movies,
}: {
  title: string;
  kicker?: string;
  movies: MovieCardData[];
}) {
  if (movies.length === 0) return null;

  return (
    <section className="mt-12">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          {kicker ? (
            <p className="text-[11px] uppercase tracking-[0.22em] text-accent">{kicker}</p>
          ) : null}
          <h2 className="font-display text-3xl text-paper">{title}</h2>
        </div>
      </div>
      <div className="rail">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} large />
        ))}
      </div>
    </section>
  );
}
