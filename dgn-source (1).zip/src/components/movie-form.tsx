"use client";

import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { QUALITIES } from "@/lib/qualities";

type GenreOption = { id: number; name: string; slug: string };
type ServerOption = { id: number; name: string; code: string };

export function MovieForm({
  genres,
  servers,
}: {
  genres: GenreOption[];
  servers: ServerOption[];
}) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setPending(true);
    const form = new FormData(event.currentTarget);
    const payload = {
      title: String(form.get("title") ?? ""),
      tagline: String(form.get("tagline") ?? ""),
      synopsis: String(form.get("synopsis") ?? ""),
      year: Number(form.get("year")),
      runtimeMinutes: Number(form.get("runtimeMinutes")),
      contentRating: String(form.get("contentRating") ?? "PG-13"),
      score: Number(form.get("score")),
      director: String(form.get("director") ?? ""),
      country: String(form.get("country") ?? ""),
      posterUrl: String(form.get("posterUrl") ?? ""),
      genreIds: form.getAll("genreIds").map((value) => Number(value)),
      featured: form.get("featured") === "on",
      trending: form.get("trending") === "on",
      link: {
        serverId: Number(form.get("serverId")),
        quality: String(form.get("quality") ?? "1080p"),
        language: String(form.get("language") ?? "English"),
        url: String(form.get("url") ?? ""),
        fileSize: String(form.get("fileSize") ?? "1.0 GB"),
      },
    };

    try {
      const response = await fetch("/api/movies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { slug?: string; error?: string };
      if (!response.ok || !data.slug) {
        setError(data.error || "Could not save title.");
        return;
      }
      router.push(`/movies/${data.slug}`);
      router.refresh();
    } catch {
      setError("Network error.");
    } finally {
      setPending(false);
    }
  }

  const field = "w-full rounded-xl border border-accent/20 bg-panel px-3 py-2 text-sm text-paper outline-none focus:border-accent";

  return (
    <form onSubmit={onSubmit} className="grid gap-5">
      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-1 text-sm">
          Title
          <input name="title" required className={field} placeholder="Neon Harbor" />
        </label>
        <label className="grid gap-1 text-sm">
          Tagline
          <input name="tagline" required className={field} placeholder="The tide remembers every crime." />
        </label>
      </div>
      <label className="grid gap-1 text-sm">
        Synopsis
        <textarea name="synopsis" required rows={4} className={field} />
      </label>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <label className="grid gap-1 text-sm">
          Year
          <input name="year" type="number" min={1900} max={2100} defaultValue={2025} required className={field} />
        </label>
        <label className="grid gap-1 text-sm">
          Runtime (min)
          <input name="runtimeMinutes" type="number" min={1} defaultValue={110} required className={field} />
        </label>
        <label className="grid gap-1 text-sm">
          Rating
          <select name="contentRating" className={field} defaultValue="PG-13">
            {["G", "PG", "PG-13", "R", "NR"].map((rating) => (
              <option key={rating}>{rating}</option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          Score
          <input name="score" type="number" min={0} max={10} step={0.1} defaultValue={7.5} required className={field} />
        </label>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-1 text-sm">
          Director
          <input name="director" required className={field} />
        </label>
        <label className="grid gap-1 text-sm">
          Country
          <input name="country" required className={field} />
        </label>
      </div>
      <label className="grid gap-1 text-sm">
        Poster URL
        <input name="posterUrl" className={field} placeholder="/images/posters/fallback.svg" />
      </label>
      <fieldset className="grid gap-2">
        <legend className="text-sm">Genres</legend>
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <label
              key={genre.id}
              className="flex items-center gap-2 rounded-full border border-accent/20 px-3 py-1 text-xs"
            >
              <input type="checkbox" name="genreIds" value={genre.id} />
              {genre.name}
            </label>
          ))}
        </div>
      </fieldset>
      <div className="flex gap-6 text-sm">
        <label className="flex items-center gap-2">
          <input type="checkbox" name="featured" /> Featured
        </label>
        <label className="flex items-center gap-2">
          <input type="checkbox" name="trending" /> Trending
        </label>
      </div>

      <div className="gold-rule my-2" />
      <h3 className="font-display text-2xl">First server link</h3>
      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-1 text-sm">
          Server
          <select name="serverId" required className={field} defaultValue={servers[0]?.id}>
            {servers.map((server) => (
              <option key={server.id} value={server.id}>
                {server.name}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          Quality
          <select name="quality" className={field} defaultValue="1080p">
            {QUALITIES.map((quality) => (
              <option key={quality}>{quality}</option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          Language
          <input name="language" defaultValue="English" className={field} />
        </label>
        <label className="grid gap-1 text-sm">
          File size
          <input name="fileSize" defaultValue="1.8 GB" className={field} />
        </label>
      </div>
      <label className="grid gap-1 text-sm">
        Stream URL
        <input
          name="url"
          required
          className={field}
          placeholder="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
        />
      </label>

      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button
        type="submit"
        disabled={pending}
        className="justify-self-start rounded-full bg-accent px-6 py-2 text-sm font-medium text-onaccent hover:bg-accent-soft disabled:opacity-60"
      >
        {pending ? "Saving…" : "Publish title"}
      </button>
    </form>
  );
}
