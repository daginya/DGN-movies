"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, useState } from "react";

export function SearchForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const query = q.trim();
    router.push(query ? `/movies?q=${encodeURIComponent(query)}` : "/movies");
  }

  return (
    <form onSubmit={onSubmit} className="relative">
      <input
        value={q}
        onChange={(event) => setQ(event.target.value)}
        placeholder="Search titles, directors…"
        className="w-full rounded-full border border-accent/20 bg-panel px-4 py-2 text-sm text-paper outline-none placeholder:text-dim focus:border-accent"
      />
    </form>
  );
}
