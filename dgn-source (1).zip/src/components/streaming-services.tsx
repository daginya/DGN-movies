import { streamingServices } from "@/lib/services";

export function StreamingServices({ title = "Where to watch" }: { title?: string }) {
  return (
    <section className="mt-12">
      <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Streaming services</p>
      <h2 className="font-display text-3xl text-paper">{title}</h2>
      <p className="mt-2 max-w-2xl text-sm text-mute">
        Official sites for the major platforms. Links open in a new tab.
      </p>
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {streamingServices.map((service) => (
          <a
            key={service.name}
            href={service.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 rounded-2xl border border-accent/15 bg-panel p-3 transition hover:border-accent hover:shadow-md"
          >
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-sm font-semibold text-white"
              style={{ background: service.color }}
              aria-hidden
            >
              {service.name.charAt(0)}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium text-paper group-hover:text-accent">
                {service.name}
              </span>
              <span className="block truncate text-[11px] text-dim">{service.note}</span>
            </span>
          </a>
        ))}
      </div>
    </section>
  );
}
