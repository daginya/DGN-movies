"use client";

import { useMemo, useState } from "react";
import type { WatchLinkData } from "@/lib/queries";
import { QUALITIES, QUALITY_LABEL } from "@/lib/qualities";

export function Player({
  title,
  posterUrl,
  links,
}: {
  title: string;
  posterUrl: string;
  links: WatchLinkData[];
}) {
  const activeLinks = useMemo(() => links.filter((link) => link.isActive), [links]);
  const available = useMemo(() => new Set(activeLinks.map((link) => link.quality)), [activeLinks]);
  const defaultQuality =
    (["1080p", ...QUALITIES] as string[]).find((q) => available.has(q)) ?? activeLinks[0]?.quality ?? "";

  const [quality, setQuality] = useState<string>(defaultQuality);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const forQuality = activeLinks.filter((link) => link.quality === quality);
  const selected =
    forQuality.find((link) => link.id === selectedId) ?? forQuality[0] ?? activeLinks[0];

  if (!selected) {
    return (
      <div className="rounded-2xl border border-accent/20 bg-panel p-8 text-mute">
        No active servers for this title yet. Add a link from the panel on the right.
      </div>
    );
  }

  function chooseQuality(q: string) {
    setQuality(q);
    setSelectedId(null);
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-accent/15 bg-black poster-shadow">
      <div className="relative aspect-video bg-black">
        <video
          key={selected.id}
          className="h-full w-full"
          controls
          playsInline
          poster={posterUrl}
          src={selected.url}
        >
          <track kind="captions" />
        </video>
        <span className="pointer-events-none absolute right-3 top-3 rounded-md bg-accent px-2 py-1 text-xs font-semibold text-onaccent">
          {selected.quality}
        </span>
      </div>

      <div className="border-t border-accent/15 bg-panel p-4">
        <p className="text-[11px] uppercase tracking-[0.2em] text-accent">Quality</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {QUALITIES.map((q) => {
            const has = available.has(q);
            const on = q === selected.quality;
            return (
              <button
                key={q}
                type="button"
                disabled={!has}
                onClick={() => chooseQuality(q)}
                title={has ? QUALITY_LABEL[q] : `${QUALITY_LABEL[q]} — not available`}
                className={`rounded-lg border px-3 py-1.5 text-sm font-medium transition ${
                  on
                    ? "border-accent bg-accent text-onaccent"
                    : has
                      ? "border-accent/30 bg-white text-paper hover:border-accent"
                      : "cursor-not-allowed border-accent/10 bg-white/50 text-dim line-through"
                }`}
              >
                {q}
              </button>
            );
          })}
        </div>
        <p className="mt-2 text-xs text-mute">{QUALITY_LABEL[selected.quality] ?? selected.quality}</p>

        <div className="mb-3 mt-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.2em] text-accent">Watch servers</p>
            <p className="mt-1 text-sm text-mute">
              Now playing {title} via {selected.server.name} · {selected.quality} · {selected.language}
            </p>
          </div>
          <p className="text-xs text-mute">
            {selected.fileSize} · {selected.server.latencyMs}ms · {selected.server.region}
          </p>
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {forQuality.map((link) => {
            const on = link.id === selected.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => setSelectedId(link.id)}
                className={`rounded-xl border px-3 py-3 text-left transition ${
                  on ? "border-accent bg-accent/10" : "border-accent/15 bg-white hover:border-accent/40"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2 text-sm text-paper">
                    <span className="h-2 w-2 rounded-full" style={{ background: link.server.accent }} />
                    {link.server.name}
                  </span>
                  <span
                    className={`text-[10px] uppercase tracking-wider ${
                      link.server.status === "online" ? "text-emerald-600" : "text-amber-600"
                    }`}
                  >
                    {link.server.status}
                  </span>
                </div>
                <p className="mt-1 text-xs text-mute">
                  {link.quality} · {link.language} · {link.fileSize} · {link.server.latencyMs}ms
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
