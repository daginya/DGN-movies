"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function WatchlistButton({ movieId, saved }: { movieId: number; saved: boolean }) {
  const router = useRouter();
  const [on, setOn] = useState(saved);
  const [pending, setPending] = useState(false);

  async function toggle() {
    setPending(true);
    try {
      const response = await fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ movieId }),
      });
      const data = (await response.json()) as { saved?: boolean };
      if (typeof data.saved === "boolean") setOn(data.saved);
      router.refresh();
    } finally {
      setPending(false);
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      className="rounded-full border border-accent/40 px-5 py-2 text-sm text-accent-soft transition hover:bg-accent/10 disabled:opacity-60"
    >
      {on ? "In watchlist" : "Add to watchlist"}
    </button>
  );
}
