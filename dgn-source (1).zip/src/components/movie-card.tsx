import Link from "next/link";
import type { MovieCardData } from "@/lib/queries";
import { formatRuntime, scoreLabel } from "@/lib/format";

export function MovieCard({
  movie,
  large = false,
}: {
  movie: MovieCardData;
  large?: boolean;
}) {
  return (
    <Link
      href={`/movies/${movie.slug}`}
      className={`group relative block overflow-hidden rounded-xl poster-shadow ${
        large ? "w-[220px] shrink-0 sm:w-[240px]" : "w-full"
      }`}
    >
      <div className={large ? "aspect-[2/3]" : "aspect-[2/3]"}>
        <img
          src={movie.posterUrl}
          alt={`${movie.title} poster`}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]"
        />
      </div>
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#2e1065]/90 via-[#2e1065]/10 to-transparent opacity-90" />
      <div className="absolute left-3 top-3 flex items-center gap-2">
        <span className="rounded-full bg-white/90 px-2 py-0.5 text-[11px] font-medium tracking-wide text-accent">
          {scoreLabel(movie.score)}
        </span>
        <span className="rounded-full bg-white/90 px-2 py-0.5 text-[11px] text-paper">
          {movie.serverCount} servers
        </span>
      </div>
      {movie.qualities[0] ? (
        <span className="absolute right-3 top-3 rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-onaccent">
          {movie.qualities[0]}
        </span>
      ) : null}
      <div className="absolute inset-x-0 bottom-0 p-3">
        <p className="font-display text-base leading-tight text-white">{movie.title}</p>
        <p className="mt-1 text-[11px] uppercase tracking-[0.14em] text-white/80">
          {movie.year} · {formatRuntime(movie.runtimeMinutes)}
        </p>
      </div>
    </Link>
  );
}
