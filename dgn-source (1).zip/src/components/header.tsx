import Link from "next/link";
import { Suspense } from "react";
import { SearchForm } from "@/components/search-form";
import { site } from "@/lib/site";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-accent/15 bg-ink/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center gap-6 px-5 py-3 lg:px-8">
        <Link href="/" className="flex items-center gap-3 shrink-0">
          <span className="grid h-9 place-items-center rounded-md border border-accent px-2.5 font-display text-sm tracking-[0.28em] text-accent">
            {site.name}
          </span>
          <span className="hidden sm:block">
            <span className="block font-display text-lg leading-none tracking-[0.22em] text-paper">
              {site.name}
            </span>
            <span className="mt-1 block text-[10px] uppercase tracking-[0.22em] text-mute">
              {site.label}
            </span>
          </span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-mute md:flex">
          {site.nav.map((item) => (
            <Link key={item.href} href={item.href} className="transition hover:text-accent-soft">
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto w-full max-w-sm">
          <Suspense fallback={<div className="h-9 rounded-full border border-accent/20 bg-panel" />}>
            <SearchForm />
          </Suspense>
        </div>
      </div>
      <nav className="flex gap-4 overflow-x-auto px-5 pb-3 text-xs uppercase tracking-[0.18em] text-mute md:hidden">
        {site.nav.map((item) => (
          <Link key={item.href} href={item.href} className="whitespace-nowrap hover:text-accent-soft">
            {item.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
