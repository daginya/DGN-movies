"use client";

import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { QUALITIES } from "@/lib/qualities";

type ServerOption = { id: number; name: string };

export function LinkForm({
  movieId,
  servers,
}: {
  movieId: number;
  servers: ServerOption[];
}) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const field =
    "w-full rounded-xl border border-accent/20 bg-panel px-3 py-2 text-sm text-paper outline-none focus:border-accent";

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/links", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          movieId,
          serverId: Number(form.get("serverId")),
          quality: String(form.get("quality") ?? "1080p"),
          language: String(form.get("language") ?? "English"),
          url: String(form.get("url") ?? ""),
          fileSize: String(form.get("fileSize") ?? "1.0 GB"),
        }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(data.error || "Could not add server link.");
        return;
      }
      event.currentTarget.reset();
      router.refresh();
    } catch {
      setError("Network error.");
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-3 rounded-2xl border border-accent/15 bg-panel p-4">
      <p className="text-[11px] uppercase tracking-[0.2em] text-accent">Mirror this title</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <select name="serverId" required className={field} defaultValue={servers[0]?.id}>
          {servers.map((server) => (
            <option key={server.id} value={server.id}>
              {server.name}
            </option>
          ))}
        </select>
        <select name="quality" className={field} defaultValue="1080p">
          {QUALITIES.map((quality) => (
            <option key={quality}>{quality}</option>
          ))}
        </select>
        <input name="language" defaultValue="English" className={field} />
        <input name="fileSize" defaultValue="1.8 GB" className={field} />
      </div>
      <input
        name="url"
        required
        className={field}
        placeholder="https://…mp4"
      />
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button
        type="submit"
        disabled={pending}
        className="justify-self-start rounded-full border border-accent px-4 py-2 text-sm text-accent-soft hover:bg-accent/10 disabled:opacity-60"
      >
        {pending ? "Adding…" : "Add server link"}
      </button>
    </form>
  );
}
