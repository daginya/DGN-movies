import Link from "next/link";
import { site } from "@/lib/site";

export function Footer() {
  const socials = [
    { key: "email", href: site.contact.email ? `mailto:${site.contact.email}` : "", label: site.contact.email },
    { key: "x", href: site.contact.x, label: "X" },
    { key: "instagram", href: site.contact.instagram, label: "Instagram" },
    { key: "telegram", href: site.contact.telegram, label: "Telegram" },
  ].filter((item) => item.href);

  return (
    <footer className="mt-20 border-t border-accent/15">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 text-sm text-mute lg:flex-row lg:items-end lg:justify-between lg:px-8">
        <div>
          <p className="font-display text-2xl tracking-[0.22em] text-paper">{site.name}</p>
          <p className="mt-2 max-w-md">{site.footerNote}</p>
          {socials.length > 0 ? (
            <p className="mt-4 flex flex-wrap gap-4 text-xs uppercase tracking-[0.16em]">
              {socials.map((item) => (
                <a
                  key={item.key}
                  href={item.href}
                  target={item.href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="hover:text-accent-soft"
                >
                  {item.label}
                </a>
              ))}
            </p>
          ) : null}
        </div>
        <div className="flex flex-wrap gap-6 uppercase tracking-[0.16em] text-xs">
          {site.footerLinks.map((item) => (
            <Link key={item.href} href={item.href} className="hover:text-accent-soft">
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </footer>
  );
}
