#!/usr/bin/env bash
# Pushes this repo to GitHub using GITHUB_TOKEN from the environment.
#
# Usage:
#   GITHUB_TOKEN=<your-token> bash scripts/push.sh
#
# Never hardcode the token here. Never commit it. This script reads it
# from the environment and strips it from the remote URL afterwards.

set -euo pipefail

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  echo "error: GITHUB_TOKEN is not set." >&2
  echo "usage: GITHUB_TOKEN=<your-token> bash scripts/push.sh" >&2
  exit 1
fi

REMOTE="https://daginya:${GITHUB_TOKEN}@github.com/daginya/DGN-movies.git"
BRANCH="main"

cleanup() {
  git remote set-url origin https://github.com/daginya/DGN-movies.git
}
trap cleanup EXIT

echo "pushing ${BRANCH} to daginya/DGN-movies ..."
git push "${REMOTE}" "${BRANCH}:main"

echo "done. token cleared from the remote URL."
