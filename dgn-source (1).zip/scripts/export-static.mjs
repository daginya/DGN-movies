// Exports the catalog from Postgres into docs/ for GitHub Pages.
// Usage: node scripts/export-static.mjs
import pg from "pg";
import fs from "node:fs";
import path from "node:path";

const url = process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
const client = new pg.Client({ connectionString: url });
await client.connect();

const q = async (sql) => (await client.query(sql)).rows;

const movies = await q(`select * from movies order by featured desc, trending desc, score desc`);
const genres = await q(`select g.name, g.slug, mg.movie_id from movie_genres mg join genres g on g.id = mg.genre_id`);
const cast = await q(`select movie_id, name, role from cast_members order by sort_order`);
const servers = await q(`select * from servers order by latency_ms`);
const links = await q(`
  select w.movie_id, w.quality, w.language, w.url, w.file_size, s.name as server, s.code, s.region, s.status, s.latency_ms, s.accent
  from watch_links w join servers s on s.id = w.server_id where w.is_active order by s.latency_ms`);
await client.end();

const img = (p) => (p.startsWith("/") ? p.slice(1) : p);

const data = {
  servers: servers.map((s) => ({ name: s.name, code: s.code, region: s.region, status: s.status, latency: s.latency_ms, accent: s.accent })),
  movies: movies.map((m) => ({
    slug: m.slug,
    title: m.title,
    tagline: m.tagline,
    synopsis: m.synopsis,
    year: m.year,
    runtime: m.runtime_minutes,
    rating: m.content_rating,
    score: Number(m.score),
    poster: img(m.poster_url),
    backdrop: img(m.backdrop_url),
    director: m.director,
    country: m.country,
    featured: m.featured,
    trending: m.trending,
    genres: genres.filter((g) => g.movie_id === m.id).map((g) => ({ name: g.name, slug: g.slug })),
    cast: cast.filter((c) => c.movie_id === m.id).map((c) => ({ name: c.name, role: c.role })),
    links: links
      .filter((l) => l.movie_id === m.id)
      .map((l) => ({
        server: l.server, code: l.code, region: l.region, status: l.status,
        latency: l.latency_ms, accent: l.accent, quality: l.quality,
        language: l.language, url: l.url, size: l.file_size,
      })),
  })),
};

const out = path.resolve("docs");
fs.mkdirSync(out, { recursive: true });
const servicesSrc = fs.readFileSync(path.resolve("src/lib/services.ts"), "utf8");
const services = [...servicesSrc.matchAll(/\{ name: "(.*?)", url: "(.*?)", color: "(.*?)", note: "(.*?)" \}/g)].map(
  ([, name, url, color, note]) => ({ name, url, color, note }),
);
fs.writeFileSync(
  path.join(out, "data.js"),
  `window.DGN_DATA = ${JSON.stringify(data)};\nwindow.DGN_SERVICES = ${JSON.stringify(services)};\n`,
);
fs.cpSync(path.resolve("public/images"), path.join(out, "images"), { recursive: true });
fs.writeFileSync(path.join(out, ".nojekyll"), "");
console.log(`exported ${data.movies.length} movies, ${links.length} links, ${servers.length} servers to docs/`);
