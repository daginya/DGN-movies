# DGN — make it yours

## Free website on GitHub Pages (easiest)

The `docs/` folder is a complete static copy of DGN (catalog, filters, multi-server player,
watchlist saved in the browser). No database or extra account needed.

1. Upload this project to `github.com/daginya/DGN-movies`.
2. In the repo: **Settings → Pages**.
3. Under **Build and deployment**: Source = **Deploy from a branch**, Branch = **main**, folder = **/docs** → **Save**.
4. After about a minute the site is live at **https://daginya.github.io/DGN-movies/**

To refresh `docs/` after changing the catalog in the database: `node scripts/export-static.mjs`

---

This is a full-stack movie catalog: Postgres + Drizzle, Next.js App Router, a multi-server player,
watchlist, and an intake form for new titles.

Everything brand-related lives in **two files**. Change those and the whole site is yours.

---

## 1. Rename it (2 minutes)

`src/lib/site.ts`

```ts
export const site = {
  name: "DGN",              // header badge, footer, tab title, favicon
  label: "Movies",          // small line under the wordmark
  tagline: "Movies from every server",
  domain: "dgnmovies.com",     // your real domain
  footerNote: "...",
  nav: [...],               // top navigation
  contact: { email: "hello@dgnmovies.com", x: "", instagram: "", telegram: "" },
};
```

That single object drives the header, footer, metadata, Open Graph tags, favicon (`src/app/icon.tsx`),
`robots.ts`, and `sitemap.ts`. No other edits needed for a rename.

## 2. Recolor it

`src/app/globals.css` → the `@theme` block:

```css
@theme {
  --color-ink: #0b0a08;        /* page background */
  --color-panel: #14110d;      /* cards */
  --color-accent: #d4a853;     /* brand color — change this one first */
  --color-accent-soft: #f0d78c;
  --color-onaccent: #1a140c;   /* text on accent buttons */
  --color-paper: #f3ead8;      /* headings */
  --color-body: #d7ccba;       /* paragraphs */
  --color-mute: #b7ae9e;
  --color-dim: #7d7668;
}
```

Every component uses token classes (`text-accent`, `bg-panel`, `border-accent/20`), so one edit
re-themes the entire site.

## 3. Swap the artwork

- `public/images/hero.jpg` — home page vault panel
- `public/images/posters/*` — poster art (2:3 works best)
- Posters are set per title in the database (`poster_url`), so you can also just paste any image URL
  in the **Add title** form.

## 4. Put it on your own domain

1. **Deploy the app** — push the repo to GitHub and import it on Vercel (or any Node host).
2. **Create a Postgres database** — Neon, Supabase, or Vercel Postgres. Copy its connection string.
3. **Set environment variables** on the host:
   ```
   DATABASE_URL=postgresql://user:pass@host/dbname
   NEXT_PUBLIC_SITE_URL=https://yourdomain.com
   ```
4. **Create the tables** — locally run `npx drizzle-kit push` pointed at that `DATABASE_URL`.
   The catalog seeds itself on the first request.
5. **Buy the domain** at any registrar (Cloudflare, Namecheap, Porkbun).
6. **Point DNS at your host** — in Vercel: *Settings → Domains → Add*, then add the `A` / `CNAME`
   records it shows you. `www` should redirect to the apex.
7. **Verify** — visit `https://yourdomain.com/api/health`; it should return `{"ok":true}`.
8. **Submit the sitemap** — `https://yourdomain.com/sitemap.xml` in Google Search Console.

Locally, `.env` already contains `DATABASE_URL`; add `NEXT_PUBLIC_SITE_URL` when you deploy.

## 5. Load your own catalog

- **UI:** `/submit` adds a title plus its first server link; each title page has *Mirror this title*
  to attach more servers.
- **API:** `POST /api/movies`, `POST /api/links`, `GET /api/movies?q=&genre=&year=&server=`.
- **Bulk:** edit `MOVIE_SEED` in `src/db/seed.ts`, then empty the tables and let it reseed:

  ```bash
  psql "$DATABASE_URL" -c 'TRUNCATE movies, genres, servers, watch_links, movie_genres, cast_members, watchlist RESTART IDENTITY CASCADE'
  ```

## 6. Legal reality check

Only publish films you have the rights to stream: your own productions, public-domain titles,
Creative Commons works (the Blender open movies included here are CC), or content you have licensed.
Linking to pirated sources is the fast way to lose the domain.

---

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | local dev server |
| `npm run build` | production build |
| `npm run start` | run the production build |
| `npx drizzle-kit push` | apply schema to the database |
| `npm run typecheck` | TypeScript check |

## Where things live

```
src/lib/site.ts        brand + nav + domain  ← rename here
src/app/globals.css    color palette         ← recolor here
src/db/schema.ts       tables
src/db/seed.ts         catalog + servers + links
src/lib/queries.ts     all database reads
src/components/        header, footer, player, forms, cards
src/app/movies/[slug]  title page with the server switcher
```
